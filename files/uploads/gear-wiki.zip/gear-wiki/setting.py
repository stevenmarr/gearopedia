#!/usr/bin/python
# -*- coding: utf-8 -*-

FILE_TYPE = {
    '1': 'Owners Manual',
    '2': 'Service Manual',
    '3': 'Firmware',
    '4': 'Software',
    '5': 'Other',
    }
